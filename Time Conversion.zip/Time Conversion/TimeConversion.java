public class TimeConversion 
{
    /**
     * Constructor
     */
    TimeConversion()
    {
        
    }


    //This method converts seconds input from the user to decaseconds
    public void showDecaseconds(double seconds)
    {
        Double decaseconds = seconds / 10;
        System.out.println("1 decasecond is equal to 10 seconds");
        System.out.println("This method converts seconds to decaseconds.");
        System.out.println(seconds + " is equal to " + decaseconds + " decaseconds.");
    }
    //This method converts seconds to jiffies
    public void showJiffies(double seconds)
    {
    Double jiffies = seconds / 100;
    System.out.println("A jiffy is equal to 10 millisenconds");
    System.out.println("This method converts seconds to jiffies.");
    System.out.println(seconds + " seconds is equal to " + jiffies + " jiffies.");
    }

    //This method converts seconds to New York minutes
    public void showNewYorkMinutes(int seconds)
    {
    int NewYorkMinutes = seconds * 20;
    System.out.println("One standard second is equivalent to 20 New York minutes.");
    System.out.println("This method will convert seconds to New York minutes.");
    System.out.println(seconds + " is equal to " + NewYorkMinutes + " New York minutes.");
    }

    //This method converts seconds to nanocenturies
    public void showNanoCenturies(double seconds) 
    {
    Double nanoCenturies = seconds / 3.156;
    System.out.println("One nanocentury is equal to 3.156 seconds.");
    System.out.println(seconds + " seconds is equal to " + nanoCenturies + " nanoCenturies.");
    }

     
    public void showScaramuccis(double seconds)
    {
    Double Scaramuccis = seconds / 950400;
    System.out.println("1 standard second is equal to 1/950400 Scaramuccis.");
    System.out.println("This method converts seconds to Scaramuccis.");
    System.out.println(seconds + " seconds is equal to " + Scaramuccis + " Scaramuccis.");
    }



    
}//end class
