import java.util.Scanner;


public class TimeConversionDriver 
{

    public static void main(String[] args) 
    {

        // statements for output formatting
        System.out.println("*******************************");
        System.out.println("Start - Time Conversion Program");
        System.out.println("*******************************");


        // variable to store user input
        int seconds;

        
          System.out.println("Enter the time in seconds: ");
          Scanner myScanner = new Scanner(System.in);
          seconds = myScanner.nextInt();
          
        
        // create TimeConversion object
         
        TimeConversion converter = new TimeConversion();
        
        // call method to calculate Decaseconds
        converter.showDecaseconds(seconds);
        
        
        
        // call method to calculate Jeffies
        converter.showJiffies(seconds);
        
        
        
        // call method to calculate New York minutes
        converter.showNewYorkMinutes(seconds);
        
        
        // call method to calculate Nano Centuries 
        converter.showNanoCenturies(seconds);
        
        
        
        // call method to calculate Scaramuccis
        converter.showScaramuccis(seconds);
        
        // statements are for output formatting
        System.out.println("*******************************");
        System.out.println("End - Time Conversion Program");
        System.out.println("*******************************");    
    
    }//end main method

}//end class
